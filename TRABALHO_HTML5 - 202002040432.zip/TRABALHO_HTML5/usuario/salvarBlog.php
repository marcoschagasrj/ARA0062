<?php
session_start ();

if ( ! isset ($_SESSION ["autenticado"])) 
{
    echo "
    <script>
        window.location.replace ('login.php')
    </script>";
}
include_once ("../servico/Bd.php");

$titulo = $_POST["titulo"];
$corpo = $_POST["corpo"];

if (isset($_POST["id"])) {
    $id = $_POST["id"];
    $sql = "update blog set titulo='$titulo',  corpo='$corpo' where id='$id' ";
}else {
    $sql = "INSERT INTO `blog` (`id`, `titulo`, `corpo`) VALUES (NULL, '$titulo', '$corpo')";
}


$bd = new Bd();
$contador = $bd->exec($sql); // insert, update e delete

echo "<h1><center> Foi incluído/atualizado $contador registro</center> </h1>";

echo "<center><a href='adicionarBlog.php'>Voltar</center> </a>";

?>
<!doctype html>
<html>
  <head>
    
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    
    <!-- Meu CSS-->
    <style>
    h3{color:white;}
    h3{background-color:#1181EF;}
    h3{font-family:"Aclonica", sans-serif;}
    h1{font-family:"Aclonica", sans-serif;}
    h4{font-size:30px;}
    p {font-size:20px;}
    
    
    </style>
    
    <link href="https://fonts.googleapis.com/css2?family=Aclonica&display=swap" rel="stylesheet">
    
    <title>Inicial - Trabalho</title>
  </head>
  <body>
    <div class="container">
        <div class="row">
                <div class="col-sm">    
        <br>
                    <div style="background-color: #1181EF">
                        <a button type="button" class="btn btn-primary btn-lg" href="index.php">Início</a>
                        
                        <!--<a button type="button" class="btn btn-primary btn-lg" href="cadastro.php">Cadastre-se</a> -->
                        
                        <a button type="button" class="btn btn-primary btn-lg" href="login.php">Login</a>
                    </div>
                </div>
        </div>
    </div> <!-- Fim desse container-->
    <br>
    
    <center><h1>Hotel Universo Acre</h1></center>
        <br>
        
    <div class="container">
            
        <div>
            <h3><center>Estilos de Apartamentos</center></h3>
        </div>
    <br>
        <div class="row pl-5">
           
                <div class="col-sm">
                    <div class="card" style="width: 18rem;">
                        <img src="#" class="card-img-top" alt="#">
                        <div class="card-body">
                            <h5 class="card-title">Apartamento Casal Duplo</h5>
                            <p class="card-text pb-4">01 Cama de Casal ou 02 de Solteiros.</p>
                            
                        </div>
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item"><b>Equipado com:</b> Central de ar, TV com controle remoto, Frigobar, Cama box, Telefone, Wi-fi.</li>
                        <li class="list-group-item"><b>Grátis Para os Hóspedes:</b> Café da manhã – Incluso no valor da diária.</li>
                        <li class="list-group-item"><b>Lavanderia:</b> Serviço de Lavanderia para os hóspedes do hotel.</li>
                        </ul>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary">Mais...</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="card" style="width: 18rem;">
                        <img src="#" class="card-img-top" alt="#">
                        <div class="card-body">
                            <h5 class="card-title">Apartamento Triplo</h5>
                            <p class="card-text">01 Cama de Casal e 01 de Solteiro ou 03 Camas de Solteiros.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item"><b>Equipado com:</b> Central de ar, TV com controle remoto, Frigobar, Cama box, Telefone, Wi-fi</li>
                        <li class="list-group-item"><b>Grátis Para os Hóspedes:</b> Café da manhã – Incluso no valor da diária.</li>
                        <li class="list-group-item"><b>Lavanderia:</b> Serviço de Lavanderia para os hóspedes do hotel.</li>
                        </ul>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary">Mais...</a> 
                        </div>
                    </div>
                </div>
                    
                <div class="col-sm">
                    <div class="card" style="width: 18rem;">
                        <img src="#" class="card-img-top" alt="#">
                        <div class="card-body">
                            <h5 class="card-title">Apartamento Quadruplo</h5>
                            <p class="card-text">01 Cama de Casal e 02 de Solteiros ou 04 Camas de Solteiros.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item"><b>Equipado com:</b> Central de ar, TV com controle remoto, Frigobar, Cama box, Telefone, Wi-fi</li>
                        <li class="list-group-item"><b>Grátis Para os Hóspedes:</b> Café da manhã – Incluso no valor da diária.</li>
                        <li class="list-group-item"><b>Lavanderia:</b> Serviço de Lavanderia para os hóspedes do hotel.</li>
                        </ul>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary">Mais...</a> 
                        </div>
                    </div>
                </div>
            </div>    
        <br>
    </div> <!-- Fim do cont 1 -->
    <div class=container>
            <h3><center>Notícias</center></h3>
            <div class="row pl-3">
                <!--Card 1 --> 
                <?php
                include_once("servico/Bd.php");
                
                $bd = new Bd();
                
                $sql = "select * from blog";
                
                foreach ($bd->query($sql) as $row) {
                    
                    echo '
                        <div class="card col-3 mb-5" style="width: 18rem;">
                            <div class="card-body">
                                <h5 class="card-title">'. $row ['titulo'].'</h5>
                                <p class="card-text">'. substr($row ['corpo'],0,60).'</p>
                                <a href="#" class="card-link"> Leia mais</a>
                            </div>
                        </div>
                    ';
                }
            
            ?>
                
            </div>
                
                     
    </div> <!-- Fim do cont -->
    <!--Começo da Tabela -->
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col"><h5><b>Apartamentos:</b></h5></th>
                    <th scope="col"><h5><b>Diária:</b></h5></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">Single</th>
                        <td>R$100,00</td>
                </tr>
                <tr>
                    <th scope="row">Duplo/Casal</th>
                        <td>R$110,00</td>
                    </tr>
                <tr>
                    <th scope="row">Twin</th>
                        <td>R$120,00</td>
                </tr>
                <tr>
                    <th scope="row">Triplo</th>
                        <td>R$130,00</td>
                </tr>
                <tr>
                    <th scope="row">Quadruplo</th>
                        <td>R$140,00</td>
                </tr>
            </tbody>
        </table>    
    </div>
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>